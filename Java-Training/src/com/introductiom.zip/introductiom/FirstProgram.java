package com.introductiom;

public class FirstProgram {
	public static void main(String arg[]){
		System.out.println("Heyy");
	}

}
