package com.introductiom;

class A {
	A(){
		System.out.println("A class");
	}
}
public class B extends A{
	B(){
		//super();
		System.out.println("B class");
	}
}
