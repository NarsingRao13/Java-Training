package com.introductiom;

public class ImplictConstructorChaining {
	public static void main(String[] agrs)
	{
		B ob= new B();
	}
}
