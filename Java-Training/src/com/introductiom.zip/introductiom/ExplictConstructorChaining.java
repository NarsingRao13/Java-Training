package com.introductiom;

public class ExplictConstructorChaining {

	public static void main(String[] args) {
		D d = new D(12);

	}

}
